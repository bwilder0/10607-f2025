"""
10607 Fall 2023 Homework 4

Instructions: Fill in the functions according to the instructions in the writeup.

Make sure you have Python and numpy installed on your system.

By Jocelyn Tseng
2023
"""

# Question 1: For the sequence functions, n is an integer >= 0
def sequence1(n):
    # YOUR CODE HERE
    pass

def sequence2(n):
    # YOUR CODE HERE
    pass

table = {}
def sequence3(n):
    # YOUR CODE HERE
    pass

# Question 2.1: n is an integer >= 1
def recursive_solution(n):
    # YOUR CODE HERE
    pass

def static_solution(n):
    # YOUR CODE HERE
    pass

# Question 2.2
def string_length(string):
    # YOUR CODE HERE
    pass

# Question 2.3
def geometric_sum(a,r,n):
    # YOUR CODE HERE
    pass

def geometric_sum_definition(a,r,n):
    # YOUR CODE HERE
    pass